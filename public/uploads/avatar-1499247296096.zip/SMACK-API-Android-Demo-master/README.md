# SMACK-API-Android-Demo
A demo XMMP android application using Android studio with SMACK Library

#Requirements
1. Android Studio 
2. Target Android SDK 23
3. SMACK API 4.1.4


#Important Thing
It is not complete example i will add various methods with time and if you want to contribute feel free to help.

#Methods Implemented (More Coming Soon)
1. XMPPTCP Connection
2. Send Message
3. Connection Listeners
